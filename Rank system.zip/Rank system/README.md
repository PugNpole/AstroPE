RankUp
========
if you use my plugin on any of your servers, please leave credit to me.
RankUp is a comically full-featured prison ranking plugin. It allows players upgrade their ranking using a certain amount of money. To manage ranks, RankUp comes with a built in group manager called DoesGroups. You can also use PurePerms to manage ranks. RankUp comes with support for both EconomyS and PocketMoney for a currency.

## Permissions
* **rankup.rankup** allows a player to use /rankup.
* **rankup.admin** does nothing now but will be used in a future release.
* **rankup.groups** do **NOT** do anything to it.

## Developed by
* @PugNpole
